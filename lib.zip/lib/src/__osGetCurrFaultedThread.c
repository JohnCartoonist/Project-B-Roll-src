#include "libultra_internal.h"

OSThread *__osGetCurrFaultedThread() {
    return D_8033489C; // 80302efc
}
