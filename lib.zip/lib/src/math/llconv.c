typedef signed long long int s64;
typedef unsigned long long int u64;
s64 __d_to_ll(double d)
{
    return d;
}
s64 __f_to_ll(float f)
{
    return f;
}
u64 __d_to_ull(double d)
{
    return d;
}
u64 __f_to_ull(float f)
{
    return f;
}
double __ll_to_d(s64 s)
{
    return s;
}
float __ll_to_f(s64 s)
{
    return s;
}
double __ull_to_d(u64 u)
{
    return u;
}
float __ull_to_f(u64 u)
{
    return u;
}
