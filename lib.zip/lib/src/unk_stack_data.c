#include "libultra_internal.h"


// only referenced in kdebugserver...
#ifdef VERSION_EU
u8 D_80365E40[0x1000];
#else
u8 D_80365E40[0x100];
#endif
