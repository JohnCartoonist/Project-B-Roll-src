#include "libultra_internal.h"
extern OSViContext *D_80334910;
OSViContext *__osViGetCurrentContext() {
    return D_80334910;
}
