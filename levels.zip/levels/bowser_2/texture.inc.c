// 0x07000000 - 0x07000800
ALIGNED8 static const u8 bowser_2_seg7_texture_07000000[] = {
#include "levels/bowser_2/0.rgba16.inc.c"
};
