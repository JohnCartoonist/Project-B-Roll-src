// 0x0E000170
const GeoLayout bowser_2_geo_000170[] = {
   GEO_CULLING_RADIUS(5000),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, bowser_2_seg7_dl_07000FE0),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
