// 0x0E0006C0
const GeoLayout bitfs_geo_0006C0[] = {
   GEO_CULLING_RADIUS(700),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, bitfs_seg7_dl_0700FD08),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
