// 0x0E000600
const GeoLayout bitfs_geo_000600[] = {
   GEO_CULLING_RADIUS(2800),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, bitfs_seg7_dl_0700BED8),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
