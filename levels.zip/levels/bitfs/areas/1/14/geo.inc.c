// 0x0E0005D0
const GeoLayout bitfs_geo_0005D0[] = {
   GEO_CULLING_RADIUS(1900),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, bitfs_seg7_dl_0700AA00),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
