// 0x0E0004F8
const GeoLayout bitfs_geo_0004F8[] = {
   GEO_CULLING_RADIUS(3200),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, bitfs_seg7_dl_070040B0),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
