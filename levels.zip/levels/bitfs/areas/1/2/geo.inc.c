// 0x0E0004B0
const GeoLayout bitfs_geo_0004B0[] = {
   GEO_CULLING_RADIUS(2700),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, bitfs_seg7_dl_07002A78),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
