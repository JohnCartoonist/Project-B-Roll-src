
const Gfx inside_castle_seg7_dl_07038350[] = {
    gsSPEndDisplayList(),
};
