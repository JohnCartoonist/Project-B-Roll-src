
Gfx inside_castle_seg7_dl_07029578[] = {
	gsSPEndDisplayList(),
};