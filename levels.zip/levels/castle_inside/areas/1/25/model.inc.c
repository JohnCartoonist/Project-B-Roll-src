

const Gfx inside_castle_seg7_dl_0703A808[] = {
    gsSPEndDisplayList(),
};
