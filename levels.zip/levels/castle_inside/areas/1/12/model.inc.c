
// 0x07031830 - 0x070318A0
const Gfx inside_castle_seg7_dl_07031830[] = {
    gsSPEndDisplayList(),
};
