
Gfx inside_castle_seg7_dl_07028FD0[] = {
	gsSPEndDisplayList(),
};