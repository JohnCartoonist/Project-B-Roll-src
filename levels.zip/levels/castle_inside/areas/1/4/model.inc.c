
Gfx inside_castle_seg7_dl_0702A650[] = {
	gsSPEndDisplayList(),
};