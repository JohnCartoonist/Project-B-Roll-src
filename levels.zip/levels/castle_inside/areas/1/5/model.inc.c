
Gfx dl_castle_lobby_wing_cap_light[] = {
	gsSPEndDisplayList(),
};