
Gfx inside_castle_seg7_dl_0702FD30[] = {
	gsSPEndDisplayList(),
};

