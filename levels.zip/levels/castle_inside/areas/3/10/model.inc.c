

const Gfx inside_castle_seg7_dl_07066FA0[] = {
    gsSPEndDisplayList(),
};
