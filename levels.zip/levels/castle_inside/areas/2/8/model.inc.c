
const Gfx inside_castle_seg7_dl_0704C7D8[] = {
    gsSPEndDisplayList(),
};

