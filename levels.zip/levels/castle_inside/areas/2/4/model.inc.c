
const Gfx inside_castle_seg7_dl_07043CD8[] = {
    gsSPEndDisplayList(),
};
