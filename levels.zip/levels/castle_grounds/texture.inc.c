// 0x07000000 - 0x07001000
ALIGNED8 static const u8 castle_grounds_seg7_texture_07000000[] = {
#include "levels/castle_grounds/0.rgba16.inc.c"
};

// 0x07001000 - 0x07002000
ALIGNED8 static const u8 castle_grounds_seg7_texture_07001000[] = {
#include "levels/castle_grounds/1.rgba16.inc.c"
};

// 0x07002000 - 0x07003000
ALIGNED8 static const u8 castle_grounds_seg7_texture_07002000[] = {
#include "levels/castle_grounds/2.rgba16.inc.c"
};
