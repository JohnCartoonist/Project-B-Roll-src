// 0x0E0006F4
const GeoLayout castle_grounds_geo_0006F4[] = {
   GEO_CULLING_RADIUS(2100),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, castle_grounds_seg7_dl_0700A290),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
