// 0x0E0006B8
const GeoLayout bits_geo_0006B8[] = {
   GEO_CULLING_RADIUS(2100),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, bits_seg7_dl_07015B60),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
