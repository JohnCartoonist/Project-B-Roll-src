// 0x0E000670
const GeoLayout bits_geo_000670[] = {
   GEO_CULLING_RADIUS(1100),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, bits_seg7_dl_07014178),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
