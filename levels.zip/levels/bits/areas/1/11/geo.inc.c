// 0x0E000508
const GeoLayout bits_geo_000508[] = {
   GEO_CULLING_RADIUS(3200),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, bits_seg7_dl_0700B4A0),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
