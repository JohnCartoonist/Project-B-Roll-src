// 0x0E000478
const GeoLayout bits_geo_000478[] = {
   GEO_CULLING_RADIUS(2500),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, bits_seg7_dl_07007AF0),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
