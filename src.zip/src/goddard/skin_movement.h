#ifndef GD_SKIN_MOVEMENT_H
#define GD_SKIN_MOVEMENT_H

#include "gd_types.h"

void func_80181760(struct ObjGroup *a0);
void move_skin(struct ObjNet *net);
void func_80181894(struct ObjJoint *joint);
void func_80181B88(struct ObjJoint *joint);

#endif // GD_SKIN_MOVEMENT_H
