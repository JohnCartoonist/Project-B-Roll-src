#include "debug_course.h"

// This is a seperate file according to Europe/Shindou
// versions. It is unknown what this file was for.

void nop_change_course(void) {
}
