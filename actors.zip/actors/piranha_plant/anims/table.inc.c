// 0x0601C31C
const struct Animation *const piranha_plant_seg6_anims_0601C31C[] = {
    &piranha_plant_seg6_anim_06017C38,
    &piranha_plant_seg6_anim_06017D88,
    &piranha_plant_seg6_anim_060187B0,
    &piranha_plant_seg6_anim_06018BA8,
    &piranha_plant_seg6_anim_06019854,
    &piranha_plant_seg6_anim_0601A014,
    &piranha_plant_seg6_anim_0601AF34,
    &piranha_plant_seg6_anim_0601AAE4,
    &piranha_plant_seg6_anim_0601B634,
    &piranha_plant_seg6_anim_0601C304,
    NULL,
};

// huh? this isnt following the Bin ID format?
UNUSED static const u64 piranha_plant_unused_1 = 1;
