// 0x0801DA4C
const struct Animation *const goomba_seg8_anims_0801DA4C[] = {
    &goomba_seg8_anim_0801DA34,
    NULL,
    NULL,
};
