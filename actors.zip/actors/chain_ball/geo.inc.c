// 0x0D0005D0
const GeoLayout metallic_ball_geo[] = {
   GEO_SHADOW(SHADOW_CIRCLE_4_VERTS, 0x96, 60),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_ALPHA, chain_ball_seg6_dl_060212E8),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
