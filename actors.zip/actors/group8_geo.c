#include <ultra64.h>
#include "sm64.h"
#include "geo_commands.h"

#include "make_const_nonconst.h"

#include "common1.h"
#include "group8.h"

#include "springboard/geo.inc.c"
#include "capswitch/geo.inc.c"
