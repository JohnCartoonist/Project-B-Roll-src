// 0x06011364
const struct Animation *const koopa_seg6_anims_06011364[] = {
    &koopa_seg6_anim_0600CC24,
    &koopa_seg6_anim_0600CFB8,
    &koopa_seg6_anim_0600D518,
    &koopa_seg6_anim_0600D804,
    &koopa_seg6_anim_0600DD90,
    &koopa_seg6_anim_0600E32C,
    &koopa_seg6_anim_0600E928,
    &koopa_seg6_anim_0600F3EC,
    &koopa_seg6_anim_0600FB1C,
    &koopa_seg6_anim_06010258,
    &koopa_seg6_anim_06010634,
    &koopa_seg6_anim_06010E48,
    &koopa_seg6_anim_0601134C, // Hmm.. these last 2 are swapped.
    &koopa_seg6_anim_060110D8,
    NULL,
    NULL,
    NULL,
};
