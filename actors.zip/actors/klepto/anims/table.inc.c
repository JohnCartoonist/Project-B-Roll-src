// 0x05008CFC
const struct Animation *const klepto_seg5_anims_05008CFC[] = {
    &klepto_seg5_anim_05005E44,
    &klepto_seg5_anim_05007574,
    &klepto_seg5_anim_050079B0,
    &klepto_seg5_anim_05007E34,
    &klepto_seg5_anim_050086C0,
    &klepto_seg5_anim_05008A18,
    &klepto_seg5_anim_05008CE4,
    NULL,
    NULL,
};
