// 0x06005E5C
const struct Animation *const moneybag_seg6_anims_06005E5C[] = {
    &moneybag_seg6_anim_06005AD8,
    &moneybag_seg6_anim_06005BEC,
    &moneybag_seg6_anim_06005C98,
    &moneybag_seg6_anim_06005D3C,
    &moneybag_seg6_anim_06005E44,
};
