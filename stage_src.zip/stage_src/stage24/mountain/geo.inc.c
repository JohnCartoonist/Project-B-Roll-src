#include "levels/mountain/area_1/geo.inc.c"
