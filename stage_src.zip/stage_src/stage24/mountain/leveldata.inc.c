#include "levels/mountain/area_1/collision.inc.c"
#include "levels/mountain/area_1/macro.inc.c"
#include "levels/mountain/area_1/spline.inc.c"
#include "levels/mountain/model.inc.c"
