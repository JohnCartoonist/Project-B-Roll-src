#include "levels/mainmap/area_1/geo.inc.c"
