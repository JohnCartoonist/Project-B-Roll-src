
extern void scroll_mainmap();

