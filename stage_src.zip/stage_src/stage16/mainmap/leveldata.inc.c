#include "levels/mainmap/area_1/collision.inc.c"
#include "levels/mainmap/area_1/macro.inc.c"
#include "levels/mainmap/area_1/spline.inc.c"
#include "levels/mainmap/model.inc.c"
