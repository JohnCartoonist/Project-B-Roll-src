const MacroObject mainmap_area_1_Area_Root_macro_objs[] = {
	MACRO_OBJECT_END(),
};

