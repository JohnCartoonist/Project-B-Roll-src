extern Vtx tower_tower_obj_mesh_vtx_0[77];
extern Gfx tower_tower_obj_mesh_tri_0[];
extern Vtx tower_tower_obj_mesh_vtx_1[56];
extern Gfx tower_tower_obj_mesh_tri_1[];
extern Vtx tower_tower_obj_mesh_vtx_2[5];
extern Gfx tower_tower_obj_mesh_tri_2[];

extern Gfx tower_tower_obj_mesh[];

