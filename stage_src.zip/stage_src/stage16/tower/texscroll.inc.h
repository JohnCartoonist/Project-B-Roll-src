
extern void scroll_actor_dl_tower();

