/********************************************************************************
						Ultra 64 MARIO Brothers

				   stage35 graphic display list module

			Copyright 1995 Nintendo co., ltd.  All rights reserved

							December 8, 1995
 ********************************************************************************/

//#include "../../headers.h"

#include "dummy_shape.sou"
#include "dummy.flk"

